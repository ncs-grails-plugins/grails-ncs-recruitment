package edu.umn.ncs

class IntensityGroup {

	String name

    static constraints = {
		name()
    }
}
